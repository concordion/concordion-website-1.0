package com.example;

public class HelloWorld {

    public String getMessage() {
        return "Hello, World!";
    }
}

