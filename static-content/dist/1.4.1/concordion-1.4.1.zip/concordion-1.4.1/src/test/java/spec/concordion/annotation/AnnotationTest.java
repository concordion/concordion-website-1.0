package spec.concordion.annotation;

import org.concordion.integration.junit3.ConcordionTestCase;

public class AnnotationTest extends ConcordionTestCase {

}
