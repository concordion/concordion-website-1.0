package test.concordion.compiler;

public class CompilerNotAvailableException extends RuntimeException {

    private static final long serialVersionUID = 9152568511213892750L;

    public CompilerNotAvailableException(String message) {
        super(message);
    }
}

