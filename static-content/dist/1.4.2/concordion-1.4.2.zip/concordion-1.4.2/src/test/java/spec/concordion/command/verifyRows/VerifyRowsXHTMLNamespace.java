package spec.concordion.command.verifyRows;

public class VerifyRowsXHTMLNamespace extends VerifyRowsTest {

}