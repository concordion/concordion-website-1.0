package org.concordion.api;

public interface ResultRecorder {

    void record(Result result);
}
