package spec.concordion;


import org.concordion.integration.junit3.ConcordionTestCase;

public class ConcordionTest extends ConcordionTestCase {

}
