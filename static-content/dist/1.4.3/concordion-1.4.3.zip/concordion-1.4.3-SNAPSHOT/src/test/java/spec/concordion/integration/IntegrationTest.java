package spec.concordion.integration;

import org.concordion.integration.junit3.ConcordionTestCase;

public class IntegrationTest extends ConcordionTestCase {

}
