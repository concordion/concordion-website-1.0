package spec.concordion.command;

import org.concordion.integration.junit3.ConcordionTestCase;

public class CommandTest extends ConcordionTestCase {

}
