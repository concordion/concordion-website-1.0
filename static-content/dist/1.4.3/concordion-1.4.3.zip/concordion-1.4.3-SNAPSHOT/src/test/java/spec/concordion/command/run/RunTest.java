package spec.concordion.command.run;

import org.concordion.integration.junit3.ConcordionTestCase;

public class RunTest extends ConcordionTestCase{

}
